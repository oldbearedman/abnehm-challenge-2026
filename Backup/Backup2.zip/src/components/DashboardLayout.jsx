﻿import React from "react";
import Podium from "./Podium";
import TrendBox from "./TrendBox";
import ProgressChart from "./ProgressChart";
import LeaderboardTable from "./LeaderboardTable";
import MonthlyWinners from "./MonthlyWinners"; 
import { Trophy } from "lucide-react";

export default function DashboardLayout({
  participants,
  leaderboard,
  activeName,
  activeId,
  monthKey,
  chartData
}) {
  const safeLeaderboard = leaderboard || [];
  const currentUser = safeLeaderboard.find(p => p.id === activeId);

  return (
    <main className="p-4 sm:p-6 max-w-[1600px] mx-auto space-y-6 pb-24 sm:pb-6">
      
      {/* OBERER BEREICH: PODIUM (links) & DETAILS (rechts) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Podium: Auf PC 2/3 Platz */}
        <div className="lg:col-span-2">
           <Podium participants={safeLeaderboard} />
        </div>
        
        {/* RECHTS OBEN: JETZT DIE DETAILS (TABELLE) */}
        <div className="lg:col-span-1 overflow-hidden h-full">
          <div className="bg-slate-900 rounded-xl border border-white/10 shadow-sm flex flex-col h-full min-h-[250px]">
            <div className="p-4 border-b border-white/10 shrink-0">
              <h2 className="font-bold text-white flex items-center gap-2">
                <Trophy size={18} className="text-yellow-500" /> Details
              </h2>
            </div>
            
            <div className="flex-1 overflow-x-auto">
              <div className="min-w-[300px]"> 
                <LeaderboardTable 
                  leaderboard={safeLeaderboard} 
                  activeId={activeId} 
                  compact={true} 
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* UNTERER BEREICH: CHART (links) & TREND/WINNER (rechts) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chart */}
        <div className="lg:col-span-2 min-h-[300px] sm:min-h-[400px]">
          <ProgressChart 
            chartData={chartData} 
            participants={participants} 
          />
        </div>

        {/* RECHTS UNTEN: TREND & HALL OF FAME */}
        <div className="lg:col-span-1 flex flex-col gap-6">
          
          {/* 1. TrendBox */}
          <div>
            <TrendBox 
              currentUser={currentUser} 
              participants={safeLeaderboard} 
              monthKey={monthKey}
            />
          </div>

          {/* 2. Hall of Fame (darunter) */}
          <div className="flex-1 min-h-[200px]">
            <MonthlyWinners />
          </div>

        </div>
      </div>
    </main>
  );
}