﻿import React, { useEffect, useState } from "react";
import { collection, onSnapshot, query, orderBy } from "firebase/firestore";
import { db } from "../lib/firebase";
import { Trophy } from "lucide-react";

export default function MonthlyWinners() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    // Holt die Gewinner aus der Datenbank "monthly_results"
    const qy = query(collection(db, "monthly_results"), orderBy("monthKey", "desc"));
    const unsub = onSnapshot(qy, (snap) => {
      const data = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      setRows(data);
    });
    return () => unsub();
  }, []);

  // HIER GEÄNDERT: "mt-3" entfernt, damit es bündig sitzt
  return (
    <div className="bg-slate-900 border border-white/10 rounded-xl p-4 h-full shadow-sm">
      <div className="text-xs font-semibold text-slate-500 mb-3 flex items-center gap-2 uppercase tracking-wider">
        <Trophy size={14} className="text-amber-500" />
        Hall of Fame
      </div>

      {rows.length === 0 ? (
        <div className="text-xs text-slate-500 py-2 italic">
          Noch keine Monatssieger.
          <br/>Der erste Pokal wird am 01.02. vergeben!
        </div>
      ) : (
        <div className="space-y-2">
          {rows.slice(0, 6).map((r) => (
            <div key={r.id} className="flex items-center justify-between bg-slate-950/50 border border-white/5 rounded-lg px-3 py-2">
              <div className="text-xs text-slate-400 font-mono">{r.monthKey}</div>
              <div className="text-sm font-bold text-amber-400 flex items-center gap-1">
                {r.winnerName}
              </div>
              <div className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                {Math.round(r.winnerScore)}%
              </div>
            </div>
          ))}
        </div>
      )}

      {rows.length > 0 && (
        <div className="mt-3 pt-3 border-t border-white/5 text-[10px] text-slate-500 text-center">
          Preis: 1x „Ja-zu-allem“-Wochenende
        </div>
      )}
    </div>
  );
}